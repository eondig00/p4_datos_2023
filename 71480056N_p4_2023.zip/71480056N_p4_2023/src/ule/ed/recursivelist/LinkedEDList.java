package ule.ed.recursivelist;

import java.util.NoSuchElementException;

public class LinkedEDList<T> implements EDList<T> {

	//	referencia al primer  de la lista
	private Node<T> front;

	

	private class Node<T> {

		Node(T element) {
			this.elem = element;
			this.next = null;
		}

		T elem;

		Node<T> next;
	}
	
	public LinkedEDList() {
		this.front = null;
	}

	
	@Override
	public boolean isEmpty() {
		return front == null;
	}


	@Override
	public int size() {
		int size = sizeRec(front);
		return size;
	}
	
	private int sizeRec(Node<T> aux) {
		int size;
		if(aux == null)
			 size = 0;
		else
			size = 1 + sizeRec(aux.next);
		return size;
	}

	
	@Override
	public void addLast(T elem) {
		if(elem == null) 
			throw new NullPointerException();
		if (isEmpty())
			front = new Node<T>(elem);
		else {
			addLastRec(front, elem, size());
		}
	}

	private void addLastRec(Node<T> aux, T elem, int remaining) {
		if(remaining == 1) {
			Node<T> nuevo = new Node<T>(elem);
			aux.next = nuevo;
		} else {
			addLastRec(aux.next, elem, remaining - 1);
		}
	}
	
	
	@Override
	public void addPos(T elem, int position) {
		if(elem == null) 
			throw new NullPointerException();
		if (position<= 0)
			throw new IllegalArgumentException();
		
		if(isEmpty() || position == 1) {	
			Node<T> nuevo = new Node<T>(elem);
			nuevo.next = front;
			front = nuevo;
		} else if (position > size()) {
				addLast(elem);
		} else {
			position = position - 1;
			addPosRec(front, elem, position);
		}
		
	}

	private void addPosRec(Node<T> aux, T elem, int remaining) {
		if(remaining == 1) {
			Node<T> nuevo = new Node<T>(elem);
			nuevo.next = aux.next;
			aux.next = nuevo;
		} else {
			addPosRec(aux.next, elem, remaining - 1);
		}
	}

	
	@Override
	public T getElemPos(int position) {
		T elem = null;
		if(position < 1 || position > size())
			throw new IllegalArgumentException();
		else if (!isEmpty())
			elem = getElemPosRec(front, position);
		return elem;
	}

	private T getElemPosRec(Node<T> aux, int pos) {
		T elem = null;
		if (aux!=null) {
			if(pos == 1) 
				elem = aux.elem;
			else 
				elem = getElemPosRec(aux.next, pos-1);	
		}
		return elem;
	}


	@Override
	public int getPosFirst(T elem) throws NoSuchElementException {
		int pos = 1;
		if(elem == null) 
			throw new NullPointerException();
		
		return getPosFirstRec(front, elem, pos);
	}

	private int getPosFirstRec(Node<T> aux, T elem, int pos) {
		if (aux == null)
	        throw new NoSuchElementException();
		if(aux.elem.equals(elem))
			return pos;
		else
			return getPosFirstRec(aux.next, elem, pos + 1);
	}


	@Override
	public int getPosLast(T elem) {
		if(elem == null) 
			throw new NullPointerException();
		int pos = size();
		LinkedEDList<T> reversedList = (LinkedEDList<T>) this.reverse();
		return getPosLastRec(reversedList.front, elem, reversedList.size());
	}

	private int getPosLastRec(Node<T> aux, T elem, int pos) {
		if (aux == null)
	        throw new NoSuchElementException();
		if(aux.elem.equals(elem))
			return pos;
		else
			return getPosLastRec(aux.next, elem, pos - 1);
	}
	
	
	@Override
	public T removelast() throws EmptyCollectionException {
		if(isEmpty())
			throw new EmptyCollectionException("SET");
		T elem = getElemPos(size());
		
		if(size() == 1) {
			front = null;
		} else if (size() == 2) {
			front.next = null;
		} else {
			removelastRec(front, size());
		}
		return elem;
	}

	private void removelastRec(Node<T> aux, int remaining) {
		if(remaining == 2) {
			aux.next = null;
		} else {
			removelastRec(aux.next, remaining - 1);
		}
	}

	

	@Override
	public T removeLastElem(T elem) throws NoSuchElementException {
		if (isEmpty()) {
	        throw new NoSuchElementException();
	    }
	    if (elem == null) {
	        throw new NullPointerException();
	    }
	    int lastPos = getPosLast(elem);
	    return removeLastElemRec(front, elem, lastPos);
	}

	private T removeLastElemRec(Node<T> aux, T elem, int remaining) {
	    if (aux == null) {
	        throw new NoSuchElementException();
	    }
	    if (remaining == 1) {
	        if (aux.elem.equals(elem)) {
	            front = front.next;
	            return elem;
	        } else {
	            throw new NoSuchElementException();
	        }
	    } else if (remaining == 2) {
	        if (aux.next.elem.equals(elem)) {
	            aux.next = aux.next.next;
	            return elem;
	        } else {
	            throw new NoSuchElementException();
	        }
	    } else {
	        return removeLastElemRec(aux.next, elem, remaining - 1);
	    }
	}

	@Override
	public EDList<T> reverse() {
        LinkedEDList<T> reverse = new LinkedEDList<T>();
        reverseRec(front, reverse);
        return reverse;
    }

    private void reverseRec(Node<T> current, LinkedEDList<T> reverse) {
        if (current == null) {
            return;
        }
        reverseRec(current.next, reverse);
        reverse.addLast(current.elem);
    }

	@Override
	public int removeOddElements(){
		return removeOddElementsRec(front, null, 1, 0);
	}

	private int removeOddElementsRec(Node<T> actual, Node<T> previo, int pos, int cont) {
		if (actual == null) {
			return cont;
		}
		if (pos % 2 != 0) {
			if (previo != null) {
				previo.next = actual.next;
			} else {
				front = actual.next;
			}
			cont++;
			actual = actual.next;
		} else {
			previo = actual;
			actual = actual.next;
		}
		return removeOddElementsRec(actual, previo, pos + 1, cont);
	}


	@Override
	public int removeConsecDuplicates() {
		if (isEmpty())
			return 0;
		else {
			int cont = removeConsecDuplicatesRec(front);
			return cont;
		}
	}

	private int removeConsecDuplicatesRec(Node<T> aux) {
		if (aux == null || aux.next == null)
			return 0;

		int cont = 0;
		if (aux.elem.equals(aux.next.elem)) {
			aux.next = aux.next.next;
			cont = 1 + removeConsecDuplicatesRec(aux);
		} else {
			cont = removeConsecDuplicatesRec(aux.next);
		}

		return cont;
	}
	

	@Override
	public String toSringExceptFromUntilReverse(int from, int until) {
		if(from <= 0 ||until <= 0 || from < until)
			throw new IllegalArgumentException();
		
		int size = size();
		if (from > size) {
	    	from = size;
	    }
	    if (until > size) {
	        return "()";
	    }
	    LinkedEDList<T> reverse = new LinkedEDList<T>();
		toStringExceptFromUntilReverseRec(front, until, from - until, reverse);
		return reverse.toString();
	}

	private void toStringExceptFromUntilReverseRec(Node<T> aux, int until, int cont, LinkedEDList<T> reverse) {
		if (aux != null) {
			if (until != 1) {
				reverse.addPos(aux.elem, 1);
				toStringExceptFromUntilReverseRec(aux.next, until -1, cont, reverse);
			} else if (cont >= 0) {
				toStringExceptFromUntilReverseRec(aux.next, until, cont-1, reverse);
			} else {
				reverse.addPos(aux.elem, 1);
				toStringExceptFromUntilReverseRec(aux.next, until, cont, reverse);
			}
		}
	}
			

	@Override
	public boolean lengthEqualsTo(int n) {
		 return lengthEqualsToRec(front, n, 0);
	}

	private boolean lengthEqualsToRec(Node<T> aux, int n, int cont) {
		if (aux == null) {
			return cont == n;
		}
		return lengthEqualsToRec(aux.next, n, cont + 1);
	}

	@Override
	public String toString() {
		return "(" + toStringRec(front) + ")";
	}

	private String toStringRec(Node<T> aux) {
		if (aux == null) {
			return "";
		}
		if (aux.next == null) {
			return aux.elem.toString() + " ";
		}
		return aux.elem.toString() + " " + toStringRec(aux.next);
	}
}
