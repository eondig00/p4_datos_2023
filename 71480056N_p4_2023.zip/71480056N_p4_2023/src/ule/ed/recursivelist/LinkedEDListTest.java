package ule.ed.recursivelist;

import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.*;


public class LinkedEDListTest {
	private LinkedEDList<String> lista;
	
	@Before
	public void test() {
		 lista= new LinkedEDList<String>();
	}

	@Test
	public void test_Vacia() {
		assertEquals(0,lista.size());
	}
	
	@Test
	public void test_AddLast() {
		lista.addLast("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addLast("3");
		Assert.assertEquals("(2 3 )", lista.toString());
		lista.addLast("7");
		Assert.assertEquals("(2 3 7 )", lista.toString());
	}
	
	/*@Test(expected=EmptyCollectionException.class)
	public void test_RemoveLastElem_Vacia() throws EmptyCollectionException{
		lista.removeLastElem("A");
	}*/

	@Test(expected=NullPointerException.class)
	public void test_addLast_ElementoNulo() {
			lista.addLast(null);
	}
	
	@Test
	public void linkedtestAddPos_Varios() {
		lista.addPos("2",1);
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addPos("3",1);
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addPos("7",2);
		Assert.assertEquals("(3 7 2 )", lista.toString());
		lista.addPos("10",3);
		Assert.assertEquals("(3 7 10 2 )", lista.toString());
		
	}
	
	// TODO  AÑADIR RESTO DE METODOS DE TESTS
	
	//testSize
	@Test
	public void testSize() {
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("7");
		Assert.assertEquals(3, lista.size());
	}
	
	@Test
	public void testGetElemPos() {
	    lista.addLast("A");
	    lista.addLast("B");
	    lista.addLast("C");
	    lista.addLast("D");
	    lista.addLast("E");
	    
	    assertEquals("A", lista.getElemPos(1));
	    assertEquals("C", lista.getElemPos(3));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testGetElemPosMayor() {
	    lista.addLast("A");
	    lista.addLast("B");
	    lista.addLast("C");
	    lista.addLast("D");
	    lista.addLast("E");
	    
	    lista.getElemPos(10);
	}

	@Test
	public void testGetPosFirst() {
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");
		lista.addLast("B");
		lista.addLast("D");
		lista.addLast("A");
	
		assertEquals(lista.getPosFirst("A"), 1);
		assertEquals(lista.getPosFirst("B"), 2);
	}
	
	@Test(expected=NoSuchElementException.class)
	public void testGetPosFirstNoEnLista() throws NoSuchElementException{
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");
		lista.addLast("B");
		lista.addLast("D");
		lista.addLast("A");
	
		lista.getPosFirst("Z");
	}
	
	@Test(expected=NullPointerException.class)
	public void testGetPosFirstElemNulo() {
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");
		lista.addLast("B");
		lista.addLast("D");
		lista.addLast("A");
	
		lista.getPosFirst(null);
	}

	
	@Test
	public void testRemoveOddElements() {
		lista.addLast("1");
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("4");
		lista.addLast("5");
		lista.addLast("6");
	
		Assert.assertEquals("(1 2 3 4 5 6 )", lista.toString());
		Assert.assertEquals(3, lista.removeOddElements());
		Assert.assertEquals("(2 4 6 )", lista.toString());
	}
	
	@Test
	public void testToSringExceptFromUntilReverse() {
		lista.addLast("1");
		lista.addLast("2");
		lista.addLast("3");
		lista.addLast("4");
		lista.addLast("5");
		lista.addLast("6");
	
		Assert.assertEquals("(1 2 3 4 5 6 )", lista.toString());
		Assert.assertEquals("(6 5 4 )", lista.toSringExceptFromUntilReverse(3, 1));
	}
	

	@Test
	public void testRemoveLastElementInLastPos() {
		lista.addLast("3");
		lista.addLast("2");
		lista.addLast("2");
		lista.addLast("3");
	
		Assert.assertEquals("3", lista.removeLastElem("3"));
		Assert.assertEquals("3", lista.removeLastElem("3"));
	}
	
	//testAddPos
	@Test
	public void testAddPos() {
	    lista.addPos("1", 1);
	    assertEquals(1, lista.size());
	    assertEquals(1, lista.getPosFirst("1"));

	    lista.addPos("2", 1);
	    assertEquals(2, lista.size());
	    assertEquals(1, lista.getPosFirst("2"));

	    lista.addPos("3", 3);
	    assertEquals(3, lista.size());
	    assertEquals(3, lista.getPosFirst("3"));

	    lista.addPos("4", 2);
	    assertEquals(4, lista.size());
	    assertEquals("(2 4 1 3 )", lista.toString());

	    lista.addPos("5", 6);
	    assertEquals(5, lista.size());
	    assertEquals("(2 4 1 3 5 )", lista.toString());

	    assertThrows(IllegalArgumentException.class, () -> lista.addPos("6", -1));
	    assertThrows(IllegalArgumentException.class, () -> lista.addPos("6", 0));

	    assertThrows(NullPointerException.class, () -> lista.addPos(null, 1));
	}
	
	//testGetElem
	@Test
	public void testGetElemPosFirst() {
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");

		String result = lista.getElemPos(1);

		assertEquals("A", result);
	}

	@Test
	public void testGetElemPosMiddle() {
	   
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");

		String result = lista.getElemPos(2);

		assertEquals("B", result);
	}

	@Test
	public void testGetElemPosLast() {

		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");

		String result = lista.getElemPos(3);

		assertEquals("C", result);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetElemPosInvalidPosNegative() {
		lista.addLast("A");
		lista.getElemPos(-1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetElemPosInvalidPosGreaterSize() {
		lista.addLast("A");
		lista.getElemPos(2);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetElemPosEmpty() {
		lista.getElemPos(1);
	}
	
	@Test(expected = NullPointerException.class)
	public void testGetPosLastWithNullElement() {
	    lista.addLast("A");
	    lista.addLast("B");
	    lista.addLast("C");
	    lista.getPosLast(null);
	}

	@Test(expected = NoSuchElementException.class)
	  public void testGetPosLastRecElemNotFound() {
	    LinkedEDList<Integer> lista2 = new LinkedEDList<>();
	    lista2.addLast(3);
	    lista2.addLast(2);
	    lista2.addLast(1);
	    lista2.getPosLast(4);
	  }
	
	@Test
	public void testRemovelast() throws EmptyCollectionException {
	    lista.addLast("1");
	    lista.addLast("2");
	    lista.addLast("3");
	    lista.addLast("4");

	    assertEquals("4", lista.removelast());
	    assertEquals("(1 2 3 )", lista.toString());

	    assertEquals("3", lista.removelast());
	    assertEquals("(1 2 )", lista.toString());

	    assertEquals("2", lista.removelast());
	    assertEquals("(1 )", lista.toString());

	    assertEquals("1", lista.removelast());
	    assertEquals("()", lista.toString());

	    assertThrows(EmptyCollectionException.class, () -> lista.removelast());
	}

	@Test
	public void testRemoveLastElem() {
	    lista.addLast("A");
	    lista.addLast("B");
	    lista.addLast("C");
	    lista.addLast("D");
	    lista.addLast("E");
	    
	    assertEquals("C", lista.removeLastElem("C"));
	    assertEquals(4, lista.size());
	    assertEquals("A", lista.getElemPos(1));
	    assertEquals("B", lista.getElemPos(2));
	    assertEquals("D", lista.getElemPos(3));
	    assertEquals("E", lista.getElemPos(4));

	    assertEquals("E", lista.removeLastElem("E"));
	    assertEquals(3, lista.size());
	    assertEquals("A", lista.getElemPos(1));
	    assertEquals("B", lista.getElemPos(2));
	    assertEquals("D", lista.getElemPos(3));

	    assertEquals("A", lista.removeLastElem("A"));
	    assertEquals(2, lista.size());
	    assertEquals("B", lista.getElemPos(1));
	    assertEquals("D", lista.getElemPos(2));

	   assertThrows(NoSuchElementException.class, () -> lista.removeLastElem("F"));

	    LinkedEDList<Integer> emptyList = new LinkedEDList<>();
	    assertThrows(NoSuchElementException.class, () -> emptyList.removeLastElem(1));
	    
	    assertThrows(NullPointerException.class, () -> lista.removeLastElem(null));
	}

	@Test
	public void testRemoveConsecDuplicates() {
	    lista.addLast("1");
	    lista.addLast("2");
	    lista.addLast("2");
	    lista.addLast("3");
	    lista.addLast("3");
	    lista.addLast("3");
	    lista.addLast("4");
	    lista.addLast("4");
	    lista.addLast("4");
	    lista.addLast("4");
	    assertEquals(6, lista.removeConsecDuplicates());
	    assertEquals("(1 2 3 4 )", lista.toString());
	    
	    LinkedEDList<String> lista2 = new LinkedEDList<>();
	    lista2.addLast("a");
	    lista2.addLast("a");
	    lista2.addLast("b");
	    lista2.addLast("c");
	    lista2.addLast("c");
	    assertEquals(2, lista2.removeConsecDuplicates());
	    assertEquals("(a b c )", lista2.toString());
	    
	    LinkedEDList<Double> lista3 = new LinkedEDList<>();
	    assertEquals(0, lista3.removeConsecDuplicates());
	    assertEquals("()", lista3.toString());
	}

	@Test
	public void testToSringExceptFromUntilReverse2() {
	    lista.addLast("1");
	    lista.addLast("2");
	    lista.addLast("3");
	    lista.addLast("4");
	    lista.addLast("5");
	    assertEquals("(2 1 )", lista.toSringExceptFromUntilReverse(5, 3));

	    LinkedEDList<String> lista2 = new LinkedEDList<>();
	    lista2.addLast("1");
	    lista2.addLast("2");
	    lista2.addLast("3");
	    lista2.addLast("4");
	    lista2.addLast("5");
	    assertEquals("(5 4 2 1 )", lista2.toSringExceptFromUntilReverse(3, 3));

	    LinkedEDList<String> lista3 = new LinkedEDList<>();
	    lista3.addLast("1");
	    lista3.addLast("2");
	    lista3.addLast("3");
	    lista3.addLast("4");
	    lista3.addLast("5");
	    assertEquals("()", lista3.toSringExceptFromUntilReverse(15, 10));

	    LinkedEDList<String> lista4 = new LinkedEDList<>();
	    lista4.addLast("1");
	    lista4.addLast("2");
	    lista4.addLast("3");
	    lista4.addLast("4");
	    lista4.addLast("5");
	    assertEquals("(1 )", lista4.toSringExceptFromUntilReverse(7, 2));

	   
	    LinkedEDList<String> lista5 = new LinkedEDList<>();
	    lista5.addLast("1");
	    lista5.addLast("2");
	    lista5.addLast("3");
	    lista5.addLast("4");
	    lista5.addLast("5");
	    assertThrows(IllegalArgumentException.class, () -> lista5.toSringExceptFromUntilReverse(2, 4));
	}

	@Test
	public void testLengthEqualsToWithEmptyList() {
	    assertTrue(lista.lengthEqualsTo(0));
	    assertFalse(lista.lengthEqualsTo(1));
	}

	@Test
	public void testLengthEqualsToWithNonEmptyList() {
	    lista.addLast("1");
	    lista.addLast("2");
	    lista.addLast("3");
	    assertTrue(lista.lengthEqualsTo(3));
	    assertFalse(lista.lengthEqualsTo(2));
	    assertFalse(lista.lengthEqualsTo(4));
	}

	
	
}
